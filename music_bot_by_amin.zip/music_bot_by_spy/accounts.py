# -*- coding: utf-8 -*-
"""
accounts.py: مخزن حسابات البوت
الحسابات تنقرأ من الملف accent.txt (كل سطر  uid:pass)
وممكن كمان من متغير البيئة ACCOUNTS (أسطر أو فواصل ،  uid:pass).
كل جلسة تاخذ حساب فاضي، وترجعه لما تخلص.
"""
import logging
import os

log = logging.getLogger("accounts")

BASE = os.path.dirname(os.path.abspath(__file__))
ACCOUNTS_FILE = os.environ.get("ACCOUNTS_FILE", os.path.join(BASE, "accent.txt"))
DEFAULT_REGION = os.environ.get("FF_REGION", "ME")
MAX_FAILS = 3          # بعد كم فشل تسجيل دخول متتالي نوقف الحساب


def parse_line(line):
    line = line.strip().lstrip("\ufeff")
    if not line or line.startswith("#") or ":" not in line:
        return None
    uid, pw = line.split(":", 1)
    uid, pw = uid.strip(), pw.strip()
    if not uid.isdigit() or not pw:
        return None
    return {"uid": uid, "password": pw, "region": DEFAULT_REGION}


class AccountPool:
    def __init__(self):
        self.accounts = []
        self.in_use = set()
        self.fails = {}
        self._next = 0
        self.reload()

    def reload(self):
        found, seen = [], set()
        try:
            with open(ACCOUNTS_FILE, "r", encoding="utf-8") as f:
                lines = f.read().splitlines()
        except FileNotFoundError:
            lines = []
        except Exception as e:
            log.warning("read accounts file failed: %s", e)
            lines = []
        env = os.environ.get("ACCOUNTS", "")
        for chunk in env.replace(",", "\n").replace(";", "\n").splitlines():
            lines.append(chunk)
        for line in lines:
            acc = parse_line(line)
            if acc and acc["uid"] not in seen:
                seen.add(acc["uid"])
                found.append(acc)
        self.accounts = found
        self.fails = {u: n for u, n in self.fails.items() if u in seen}
        self.in_use &= seen | self.in_use      # لا نفقد حسابات شغالة حالياً
        log.info("accounts loaded: %d", len(found))
        return len(found)

    def usable(self):
        return [a for a in self.accounts if self.fails.get(a["uid"], 0) < MAX_FAILS]

    def acquire(self):
        """يرجع حساب فاضي (أو None)"""
        usable = self.usable()
        n = len(usable)
        for i in range(n):
            acc = usable[(self._next + i) % n]
            if acc["uid"] not in self.in_use:
                self._next = (self._next + i + 1) % n
                self.in_use.add(acc["uid"])
                return acc
        return None

    def release(self, uid):
        self.in_use.discard(str(uid))

    def report_ok(self, uid):
        self.fails.pop(str(uid), None)

    def report_fail(self, uid):
        uid = str(uid)
        self.fails[uid] = self.fails.get(uid, 0) + 1

    def add(self, uid, password):
        acc = parse_line(f"{uid}:{password}")
        if not acc:
            return False
        if any(a["uid"] == acc["uid"] for a in self.accounts):
            return None            # موجود من قبل
        try:
            with open(ACCOUNTS_FILE, "a", encoding="utf-8") as f:
                f.write(f"\n{acc['uid']}:{acc['password']}")
        except Exception as e:
            log.warning("append account failed: %s", e)
        self.accounts.append(acc)
        return True

    def stats(self):
        usable = self.usable()
        bad = len(self.accounts) - len(usable)
        busy = len([a for a in usable if a["uid"] in self.in_use])
        return {"total": len(self.accounts), "usable": len(usable), "busy": busy,
                "free": len(usable) - busy, "bad": bad}


pool = AccountPool()
