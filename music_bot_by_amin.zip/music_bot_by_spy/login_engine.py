#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Free Fire login engine — standalone CLI wrapper.

Usage:
  python3 ff_login.py <uid> <password> [region]

Requires the original Pb2 package/files alongside this script.
Install dependencies:
  pip install httpx pycryptodome google-play-scraper protobuf-decoder
"""

import asyncio, random, uuid, time, json
import httpx
from datetime import datetime
from google_play_scraper import app as play_scraper
from protobuf_decoder.protobuf_decoder import Parser
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad

from Pb2 import MajoRLoGinrEs_pb2, PorTs_pb2

AES_KEY = b'Yg&tc%DEuh6%Zc^8'
AES_IV  = b'6oyZDr22E3ychjM%'

REGION_LANG = {
    "BD": "bn", "IND": "hi", "PK": "ur", "SG": "en", "ID": "id",
    "ME": "ar", "VN": "vi", "TW": "zh", "CIS": "ru", "TH": "th",
    "EU": "en", "US": "en", "SAC": "es", "LK": "en", "BR": "pt",
}

DEFAULT_HEADERS = {
    'User-Agent': 'UnityPlayer/2018.4.12f1 (UnityWebRequest/1.0, libcurl/8.5.0-DEV)',
    'Connection': 'Keep-Alive', 'Accept-Encoding': 'gzip',
    'Content-Type': 'application/x-www-form-urlencoded',
    'Expect': '100-continue', 'X-Unity-Version': '2018.4.12f1',
    'X-GA-SV': '1789535859', 'X-GA': 'v1 1', 'ReleaseVersion': 'OB55'
}


def _pb_varint(n):
    if n < 0: n = (1 << 64) + n
    out = bytearray()
    while True:
        b = n & 0x7F
        n >>= 7
        if n: b |= 0x80
        out.append(b)
        if not n: break
    return bytes(out)


def _pb_tag(f, w): return _pb_varint((f << 3) | w)


def _pb_field(f, v):
    if isinstance(v, bool): v = int(v)
    if isinstance(v, int): return _pb_tag(f, 0) + _pb_varint(v)
    if isinstance(v, str):
        d = v.encode('utf-8')
        return _pb_tag(f, 2) + _pb_varint(len(d)) + d
    if isinstance(v, (bytes, bytearray)):
        d = bytes(v)
        return _pb_tag(f, 2) + _pb_varint(len(d)) + d
    return b""


async def aes_encrypt(payload, key, iv):
    cipher = AES.new(key, AES.MODE_CBC, iv)
    return cipher.encrypt(pad(payload, AES.block_size))


def get_proto_field(d, key, default=None):
    if not d or not isinstance(d, dict): return default
    if key in d: return d[key].get('data', default)
    if str(key) in d: return d[str(key)].get('data', default)
    return default


async def parse_results(parsed_results):
    result_dict = {}
    for result in parsed_results:
        field_data = {"wire_type": result.wire_type}
        if result.wire_type in ("varint", "string", "bytes"):
            field_data["data"] = result.data
        elif result.wire_type == "length_delimited":
            if hasattr(result.data, "results"):
                field_data["data"] = await parse_results(result.data.results)
            elif isinstance(result.data, list):
                field_data["data"] = await parse_results(result.data)
            else:
                field_data["data"] = str(result.data)
        result_dict[str(result.field)] = field_data
    return result_dict


async def get_playstore_version():
    loop = asyncio.get_event_loop()
    try:
        res = await loop.run_in_executor(
            None, lambda: play_scraper('com.dts.freefireth', lang='hi', country='id'))
        return res.get("version", "1.132.8")
    except Exception:
        return "1.132.8"


async def version_config(client_http, region="IND"):
    app_version = await get_playstore_version()
    lang = REGION_LANG.get(region, "hi")
    api_url = (f"https://version.ggwhitehawk.com/live/ver.php?version={app_version}"
               f"&lang={lang}&device=android&channel=android&appstore=googleplay"
               f"&region={region}&whitelist_version=1.3.0&whitelist_sp_version=1.0.0")
    try:
        res = await client_http.get(api_url)
        data = res.json()
        return data.get("latest_release_version"), data.get("remote_version"), data.get("server_url")
    except Exception:
        return None


async def get_access_token(client_http, uid, password):
    url = "https://100067.connect.garena.com/oauth/guest/token/grant"
    hdrs = {
        "Host": "100067.connect.garena.com",
        "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 12; SM-G998B Build/SP1A.210812.016)",
        "Content-Type": "application/x-www-form-urlencoded",
        "Accept-Encoding": "gzip, deflate, br", "Connection": "close"
    }
    data = {
        "uid": str(uid), "password": str(password), "response_type": "token",
        "client_type": "2",
        "client_secret": "2ee44819e9b4598845141067b281621874d0d5d7af9d8f7e00c1e54715b7d1e3",
        "client_id": "100067"
    }
    for _ in range(3):
        try:
            r = await client_http.post(url, headers=hdrs, data=data)
            if r.status_code == 200:
                rd = r.json()
                return rd.get("open_id"), rd.get("access_token"), rd.get("platform", 4)
        except Exception:
            pass
        await asyncio.sleep(0.5)
    return None


async def build_majorlogin_payload(open_id, access_token, platform, client_version):
    """
    Builds the MajorLogin payload using the device/network values supplied
    in the updated configuration. Fields not present in the local protobuf
    schema are appended as raw protobuf fields.
    """
    try:
        from Pb2 import MajoRLoGinrEq_pb2 as ML

        proto = ML.MajorLogin()
        proto.event_time = time.strftime("%Y-%m-%d %H:%M:%S")
        proto.game_name = "free fire"
        proto.platform_id = 1
        proto.client_version = "1.132.9"
        proto.system_software = (
            "Android OS 14 / API-34 (UP1A.231005.007/V816.0.15.0.UNQMIXM)"
        )
        proto.system_hardware = "Handheld"
        proto.telecom_operator = "Grameenphone"
        proto.network_type = "CarrierDataNetwork"
        proto.screen_width = 1666
        proto.screen_height = 750
        proto.screen_dpi = "352"
        proto.processor_details = "ARM64 FP ASIMD AES | 2400 | 8"
        proto.memory = 5563
        proto.gpu_renderer = "Mali-G57 MC2"
        proto.gpu_version = (
            "OpenGL ES 3.2 v1.r32p1-01eac0.0a0b917d9265b4c01be9925306306139"
        )
        proto.unique_device_id = "Google|9cc73f7a-91f6-40f6-87ec-5b67e597eb8c"
        proto.client_ip = "59.152.5.188"
        proto.language = "en"
        proto.open_id = str(open_id)
        proto.open_id_type = "8"
        proto.device_type = "Handheld"
        proto.access_token = str(access_token)
        proto.platform_sdk_id = 1
        proto.network_operator_a = "Grameenphone"
        proto.network_type_a = "Cellular"
        proto.client_using_version = "7428b253defc164018c604a1ebbfebdf"

        proto.external_storage_total = 109685
        proto.external_storage_available = 58294
        proto.internal_storage_total = 797
        proto.internal_storage_available = 18000
        proto.game_disk_storage_available = 58818
        proto.game_disk_storage_total = 109685
        proto.external_sdcard_avail_storage = 58818
        proto.external_sdcard_total_storage = 109685

        proto.login_by = 2
        proto.library_path = (
            "/data/app/~~cqQgpdMykLQEM3odipXatw==/"
            "com.dts.freefireth-G6e5yOt1dtuXG5Ambhj18g==/lib/arm64"
        )
        proto.reg_avatar = 1
        proto.library_token = (
            "b8e0cd5e295eee42f5860d3c86e483dd|"
            "/data/app/~~cqQgpdMykLQEM3odipXatw==/"
            "com.dts.freefireth-G6e5yOt1dtuXG5Ambhj18g==/base.apk"
        )
        proto.channel_type = 3
        proto.cpu_type = 2
        proto.cpu_architecture = "64"
        proto.client_version_code = "2019121229"
        proto.graphics_api = "OpenGLES2"
        proto.supported_astc_bitset = 4095
        proto.login_open_id_type = 8
        proto.analytics_detail = (
            b"FwQVTgUPX1UaUllDDwcWCRBpWAUOUgsvA1snWlBaO1kFYg=="
        )
        proto.loading_time = 8043
        proto.release_channel = "android"
        proto.extra_info = (
            "KqsHT4XbSZhqerDNUhjbS3DxG/4+I62zQU2tZFJN91kBUICAlZ5yujshLKvjlk/"
            "KiShfKfis8EeB1PMhFHIodWPncZC4fCHYF3TcTwNj95aWY/S3"
        )
        proto.android_engine_init_flag = 111207
        proto.if_push = 1
        proto.is_vpn = 1
        proto.origin_platform_type = "4"
        proto.primary_platform_type = "4"

        base_payload = proto.SerializeToString()
        extra = b""
        extra += _pb_field(73, 2)
        extra = b""
        extra += _pb_field(85, 3)
        extra += _pb_field(90, "Dhaka")
        extra += _pb_field(91, "C")
        extra += _pb_field(96, '{"cur_rate":[60,90,120],"support_etc2":false}')
        extra += _pb_field(102, "GQ]        e")
        extra += _pb_field(103, 1)
        extra += _pb_field(104, 45174)
        extra += _pb_field(105, 1)
        extra += _pb_field(
            106,
            "https://dl-bs.ggpolarbear.com/live/ABHotUpdates/|"
            "https://core-bs.ggpolarbear.com/live/ABHotUpdates/|"
            "a4332cb1c1a84e51dd77441e4856ed5a",
        )
        extra += _pb_field(107, "1.9393e7b8e53e8aeb")
        return await aes_encrypt(base_payload + extra, AES_KEY, AES_IV)
    except Exception as e:
        print(f"[BUILD ERROR] {e}")
        return None


async def send_majorlogin(client_http, data, release_version, server_url):
    try:
        url = f"{server_url}MajorLogin" if server_url.endswith('/') else f"{server_url}/MajorLogin"
        req_headers = DEFAULT_HEADERS.copy()
        req_headers["ReleaseVersion"] = str(release_version)
        response = await client_http.post(url, headers=req_headers, data=data)
        if response.status_code != 200 or len(response.content) < 40:
            return None
        res_proto = MajoRLoGinrEs_pb2.MajorLoginRes()
        try: res_proto.ParseFromString(response.content)
        except Exception: pass
        if not (res_proto.account_uid and res_proto.token):
            for offset in range(min(128, len(response.content))):
                try:
                    c = MajoRLoGinrEs_pb2.MajorLoginRes()
                    c.ParseFromString(response.content[offset:])
                    if c.account_uid and c.token: res_proto = c; break
                except Exception: pass
        parsed = Parser().parse(response.content.hex())
        dict_res = await parse_results(parsed)
        key_val = get_proto_field(dict_res, 22) or res_proto.key or AES_KEY
        iv_val = get_proto_field(dict_res, 23) or res_proto.iv or AES_IV
        if isinstance(key_val, str):
            try: key_val = bytes.fromhex(key_val)
            except Exception: pass
        if isinstance(iv_val, str):
            try: iv_val = bytes.fromhex(iv_val)
            except Exception: pass
        res_proto.key = key_val
        res_proto.iv = iv_val
        if not res_proto.url: res_proto.url = server_url
        return res_proto
    except Exception as e:
        print(f"[MAJORLOGIN ERROR] {e}")
        return None


async def send_getlogin(client_http, data, base_url, token, release_version):
    try:
        url = f"{base_url.rstrip('/')}/GetLoginData"
        req_headers = DEFAULT_HEADERS.copy()
        req_headers["ReleaseVersion"] = str(release_version)
        req_headers['Authorization'] = f"Bearer {token}"
        response = await client_http.post(url, headers=req_headers, data=data)
        if response.status_code != 200: return None
        res_proto = PorTs_pb2.GetLoginData()
        try: res_proto.ParseFromString(response.content)
        except Exception: pass
        parsed = Parser().parse(response.content.hex())
        dict_res = await parse_results(parsed)
        return res_proto, dict_res, response.content
    except Exception as e:
        print(f"[GETLOGIN ERROR] {e}")
        return None


async def do_login(uid, password, region_pref="IND"):
    async with httpx.AsyncClient(verify=False, timeout=15.0) as client_http:
        print("[*] Fetching version config...")
        vc = await version_config(client_http, region_pref)
        if not vc:
            print("[-] Version config error"); return None
        release_version, client_version, server_url = vc
        print(f"[+] Version: {client_version} | Release: {release_version}")

        print("[*] Getting Access Token...")
        tg = await get_access_token(client_http, uid, password)
        if not tg:
            print("[-] Invalid credentials"); return None
        open_id, access_token, platform = tg

        print("[*] Building MajorLogin payload...")
        payload = await build_majorlogin_payload(open_id, access_token, platform, client_version)
        if not payload:
            print("[-] Build failed"); return None

        major_res = await send_majorlogin(client_http, payload, release_version, server_url)
        if not major_res or not major_res.account_uid:
            print("[-] MajorLogin rejected"); return None

        print("[*] Getting Login Data...")
        gl = await send_getlogin(client_http, payload, major_res.url, major_res.token, release_version)
        if not gl:
            print("[-] GetLoginData failed"); return None
        res_proto, dict_res, login_data_raw = gl

        online_addr = res_proto.Online_IP_Port or get_proto_field(dict_res, 14, "0.0.0.0:0")
        if ':' in online_addr:
            online_ip, online_port = online_addr.split(":")
        else:
            online_ip, online_port = "0.0.0.0", "0"

        chat_addr = res_proto.AccountIP_Port or get_proto_field(dict_res, 32, online_addr)
        if ':' in chat_addr:
            chat_ip, chat_port = chat_addr.split(":")
        else:
            chat_ip, chat_port = online_ip, online_port

        return {
            "bot_uid":      str(major_res.account_uid),
            "token":        major_res.token,
            "region":       major_res.region or region_pref,
            "key":          major_res.key or AES_KEY,
            "iv":           major_res.iv or AES_IV,
            "timestamp":    major_res.timestamp or int(time.time()),
            "online_ip":    online_ip,
            "online_port":  online_port,
            "chat_ip":      chat_ip,
            "chat_port":    chat_port,
            "account_name": res_proto.AccountName or "Unknown",
            "clan_id":      res_proto.Clan_ID or 0,
            "clan_data":    res_proto.Clan_Compiled_Data or "",
            "server_url":   major_res.url,
            "login_data_raw": login_data_raw,
        }

def _json_safe(value):
    """Convert bytes and nested values into JSON-serializable values."""
    if isinstance(value, (bytes, bytearray)):
        return value.hex()
    if isinstance(value, dict):
        return {str(k): _json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(v) for v in value]
    return value


async def main():
    import sys

    if len(sys.argv) < 3:
        print("Usage: python3 ff_login.py <uid> <password> [region]")
        print("Example: python3 ff_login.py 8358907840 mypassword ME")
        return

    uid = sys.argv[1]
    password = sys.argv[2]
    region = sys.argv[3].upper() if len(sys.argv) > 3 else "IND"

    result = await do_login(uid, password, region)
    if result:
        print(json.dumps(_json_safe(result), indent=2))
    else:
        raise SystemExit(1)


if __name__ == "__main__":
    asyncio.run(main())
