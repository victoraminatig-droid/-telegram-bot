# -*- coding: utf-8 -*-
import os
import asyncio
import logging
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes

import login_engine
from squad_bot import SquadBot
from accounts import pool

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)
# لا نطبع روابط تيليجرام في السجل (فيها التوكن)
logging.getLogger("httpx").setLevel(logging.WARNING)
logging.getLogger("httpcore").setLevel(logging.WARNING)

TELEGRAM_BOT_TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN", "9016394114:AAGY72dWzom4tRkOv9GSTBzM-whxBvN1YO8")
if not TELEGRAM_BOT_TOKEN:
    raise SystemExit("حط توكن البوت في متغير البيئة TELEGRAM_BOT_TOKEN")


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "🎵 أهلاً! أنا بوت الموسيقى لفري فاير.\n\n"
        "▫️ /music <كود_الفريق> [أغنية] ← أدخل فريقك\n"
        "▫️ /play [رابط/اسم] ، /resume ، /stop\n\n"
        "داخل اللعبة اكتب في شات الفريق: !help")


# ═══════════════════════════ بوت الفريق: موسيقى داخل اللعبة ═══════════════════════════
squad_bots = {}             # telegram_id -> SquadBot
AUTO_LEAVE_SECONDS = 1800   # يطلع من الفريق بعد 30 دقيقة


def _drop_bot(tid, bot):
    if squad_bots.get(tid) is bot:
        squad_bots.pop(tid, None)


async def _new_bot(tid):
    """ياخذ حساب فاضي من المخزن ويسجل دخول ويفتح اتصالات اللعبة. يرجع (bot, None) أو (None, رسالة_خطأ)"""
    old = squad_bots.pop(tid, None)
    if old:
        await old.close()
    if not pool.accounts:
        return None, "⚠️ ما في حسابات مضافة للبوت حالياً."
    acc = pool.acquire()
    if not acc:
        return None, "⚠️ كل حسابات البوت مشغولة حالياً، جرب بعد شوي."
    try:
        login = await login_engine.do_login(acc["uid"], acc["password"], acc["region"])
    except Exception as ex:
        logging.warning("login error for account ...%s: %s", acc["uid"][-4:], ex)
        login = None
    if not login:
        pool.report_fail(acc["uid"])
        pool.release(acc["uid"])
        return None, "❌ تعذر تسجيل دخول حساب البوت، جرب مرة ثانية."
    pool.report_ok(acc["uid"])

    def _closed(b, _uid=acc["uid"]):
        pool.release(_uid)
        _drop_bot(tid, b)

    bot = SquadBot(login, on_close=_closed)
    try:
        await bot.connect()
    except Exception as ex:
        await bot.close()
        return None, f"❌ تعذر الاتصال بسيرفر اللعبة: {ex}"
    squad_bots[tid] = bot
    return bot, None


async def _auto_leave(tid, bot):
    await asyncio.sleep(AUTO_LEAVE_SECONDS)
    if squad_bots.get(tid) is bot:
        await bot.close()


async def music_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/music <كود_الفريق> [أغنية] ← يدخل الفريق ويبدأ الموسيقى"""
    tid = update.effective_user.id
    if not context.args or not context.args[0].isdigit():
        await update.message.reply_text("❌ الصيغة: /music <كود_الفريق>\nمثال: /music 5592884")
        return
    team_code = context.args[0]
    query = " ".join(context.args[1:]).strip()
    msg = await update.message.reply_text(f"🔄 جاري الانضمام للفريق {team_code} ...")
    try:
        bot, err = await _new_bot(tid)
        if err:
            await msg.edit_text(err)
            return
        if not await bot.join(team_code):
            await bot.close()
            await msg.edit_text("❌ ما قدرت أنضم للفريق. تأكد من الكود وإن الفريق مفتوح.")
            return
        asyncio.create_task(_auto_leave(tid, bot))
        await msg.edit_text(
            f"✅ انضممت للفريق {team_code} وأرسلت الأوامر في الشات.\n"
            "اكتب الأوامر من داخل اللعبة في شات الفريق:\n"
            "!play [رابط/اسم] ، !stop ، !resume ، !help")
        if query:
            await asyncio.sleep(3)
            await bot.handle_command("!play " + query)
    except Exception as ex:
        await msg.edit_text(f"❌ خطأ: {ex}")


async def _forward_command(update, text):
    bot = squad_bots.get(update.effective_user.id)
    if not bot or not bot.in_team:
        await update.message.reply_text("⚠️ البوت مو في فريق. استخدم أول: /music <كود_الفريق>")
        return
    await bot.handle_command(text)
    await update.message.reply_text("✅ تم.")


async def play_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = " ".join(context.args).strip()
    if not q:
        await update.message.reply_text("❌ الصيغة: /play [رابط أو اسم أغنية]")
        return
    await _forward_command(update, "!play " + q)


async def resume_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await _forward_command(update, "!resume")


async def stop_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    tid = update.effective_user.id
    bot = squad_bots.pop(tid, None)
    if bot:
        await bot.close()
        await update.message.reply_text("⏹ تم الإيقاف والخروج من الفريق.")
    else:
        await update.message.reply_text("ما في شي شغال.")


# ═══════════════════════════ تشغيل البوت ═══════════════════════════
if __name__ == "__main__":
    app = ApplicationBuilder().token(TELEGRAM_BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("music", music_command))
    app.add_handler(CommandHandler("play", play_command))
    app.add_handler(CommandHandler("resume", resume_command))
    app.add_handler(CommandHandler("stop", stop_command))
    print("🚀 البوت يعمل الآن...")
    app.run_polling()
