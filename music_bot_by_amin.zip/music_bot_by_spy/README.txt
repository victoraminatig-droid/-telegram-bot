نسخة مبسطة فيها أمر /music فقط.

pip install -r requirements.txt
export TELEGRAM_BOT_TOKEN="التوكن الجديد"
python main.py

حط حساب اللعبة في accent.txt بصيغة  uid:pass
أو في متغير البيئة ACCOUNTS (مناسب لو رفعته على استضافة مثل Railway).

الاستخدام:
  /music <كود_الفريق> [اسم أغنية]   يدخل الفريق مباشرة
  /play [رابط/اسم] ، /resume ، /stop
  داخل اللعبة، في شات الفريق: !play !resume !stop !help

يحتاج ffmpeg منصّب على الجهاز عشان الصوت يشتغل.
لو يوتيوب رفض التحميل، حط كوكيز يوتيوب في متغير YT_COOKIES.
